const homeTpl = require('../views/home.html')
const positionController = require('../controllers/position')
const searchController = require('../controllers/search')
const profileController = require('../controllers/profile')

const render = () => {
  document.querySelector('#root').innerHTML = homeTpl
  changeTab()
}

const changeTab = () => {
  $('nav li').on('tap', function () {
    let controllers = [positionController, searchController, profileController]
    controllers[$(this).index()].render()
    $(this).addClass('active').siblings().removeClass('active')
  })
}

module.exports = {
  render
}