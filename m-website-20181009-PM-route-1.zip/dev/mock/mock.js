const list = require('./list.json')

module.exports = function() {
  return {
    list
  }
}