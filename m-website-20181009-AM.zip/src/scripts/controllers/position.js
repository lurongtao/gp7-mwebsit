const positionTpl = require('../views/position.html')
const positionModel = require('../models/position')

const render = async () => {
  let result = await positionModel.list()
  let list = result.content.data.page.result
  let template = Handlebars.compile(positionTpl)
  let html = template({ list })
  $('main').html(html)
}

module.exports = {
  render
}