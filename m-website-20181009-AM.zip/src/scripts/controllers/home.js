const homeTpl = require('../views/home.html')

const render = () => {
  document.querySelector('#root').innerHTML = homeTpl
}

module.exports = {
  render
}