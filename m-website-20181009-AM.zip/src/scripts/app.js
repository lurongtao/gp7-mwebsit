const homeController = require('./controllers/home')
const positionController = require('./controllers/position')

homeController.render()
positionController.render()