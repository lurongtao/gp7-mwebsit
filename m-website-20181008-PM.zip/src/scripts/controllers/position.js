const positionTpl = require('../views/position.html')

const render = () => {
  document.querySelector('main').innerHTML = positionTpl
}

module.exports = {
  render
}