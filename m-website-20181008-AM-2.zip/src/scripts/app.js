// // 3、引入模块
// const name = require('./name.js')

// // 4、使用模块
// console.log(name.sayName())

const homeTpl = require('./views/home.html')

document.querySelector('#root').innerHTML = homeTpl