// 1、定义模块
const foo = {
  name: 'xinya',
  sayName: function() {
    return this.name
  }
}

// 2、暴露接口
module.exports = foo